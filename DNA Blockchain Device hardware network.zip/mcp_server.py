"""
MCP (Model Context Protocol) server for the research pipeline.

MCP is the open standard for connecting AI assistants (Claude, and others)
to external tools and data sources. This server exposes the research
pipeline's public endpoints as MCP tools, so any MCP-compatible AI
assistant can query the chain, ask research questions, and look up gene
patterns -- without any special integration work.

HOW THIS WORKS IN PRACTICE:
  A user talking to an AI assistant (e.g. in a browser extension or IDE)
  says "what does the research chain show about BRCA1?" and the AI
  automatically calls this MCP server's query_gene tool, reads the
  grounded response, and explains it -- all without the user needing to
  know the API exists or how to call it.

TO RUN:
  python3 mcp_server.py --node-url http://YOUR_IP:5001 --research-url http://YOUR_IP:5050
  Then point your MCP-compatible client at http://localhost:8080/mcp

PLATFORMS THIS ENABLES (once deployed on a real server):
  - Claude desktop (via MCP configuration)
  - Any IDE with an MCP-compatible AI assistant
  - Browser extensions that support MCP
  - LangChain and other agent frameworks (via MCP bridge)
  - Custom bots that implement the MCP client protocol
"""

from __future__ import annotations

import argparse
import json
from typing import Dict, Any, List

import requests
from flask import Flask, request, jsonify

app = Flask(__name__)
NODE_URL = "http://localhost:5001"
RESEARCH_URL = "http://localhost:5050"

# MCP tool definitions -- these are what AI assistants read to understand
# what this server can do and how to call each tool.
MCP_TOOLS = [
    {
        "name": "query_research_chain",
        "description": (
            "Ask a plain-language question about the public genomic research "
            "blockchain. Returns an AI-generated answer grounded against actual "
            "chain data, with verification status per claim. "
            "No authentication required. Good for: 'what genes appear most in "
            "the research data', 'what is the average risk score', 'how many "
            "records are in the chain'."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "A plain-language question about the research data"
                }
            },
            "required": ["question"]
        }
    },
    {
        "name": "lookup_gene",
        "description": (
            "Look up a specific gene in the public research pool and return "
            "how many records contain it, associated risk scores, and an "
            "AI explanation. No authentication required."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "gene_name": {
                    "type": "string",
                    "description": "Gene symbol e.g. BRCA1, TP53, MLH1"
                }
            },
            "required": ["gene_name"]
        }
    },
    {
        "name": "get_research_summary",
        "description": (
            "Get a plain-language AI summary of the entire research chain and "
            "public pool -- total records, gene frequency, risk distribution, "
            "trial matches. Fully grounded against chain data. No auth required."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "beacon_query",
        "description": (
            "Query whether a specific gene exists in any Beacon-compatible "
            "research provider's data -- returns existence (yes/no) and count. "
            "Follows the real GA4GH Beacon protocol used by real research "
            "institutions worldwide. No individual records disclosed."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "gene": {
                    "type": "string",
                    "description": "Gene symbol to query across providers"
                },
                "provider_url": {
                    "type": "string",
                    "description": "Beacon provider URL (default: first configured provider)"
                }
            },
            "required": ["gene"]
        }
    },
    {
        "name": "get_chain_state",
        "description": (
            "Get the current blockchain state: number of blocks, tip hash, "
            "whether all nodes are in consensus. Useful for verifying the "
            "network is running and agreed."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    },
]


@app.route("/mcp/tools", methods=["GET"])
def list_tools():
    """MCP discovery endpoint -- AI assistants call this first to learn
    what tools this server provides."""
    return jsonify({"tools": MCP_TOOLS})


@app.route("/mcp/call", methods=["POST"])
def call_tool():
    """MCP execution endpoint -- AI assistants call this to invoke a tool."""
    data = request.get_json(force=True)
    tool_name = data.get("name")
    tool_input = data.get("input", {})

    try:
        if tool_name == "query_research_chain":
            question = tool_input.get("question", "")
            resp = requests.get(f"{RESEARCH_URL}/ai/ask",
                                 params={"q": question}, timeout=15)
            result = resp.json()
            return jsonify({
                "content": [{
                    "type": "text",
                    "text": (
                        f"Answer: {result.get('answer', '')}\n\n"
                        f"Grounding status: {result.get('grounding', {}).get('overall_status', 'unknown')}\n"
                        f"Source: {result.get('data_source', '')}"
                    )
                }]
            })

        elif tool_name == "lookup_gene":
            gene = tool_input.get("gene_name", "")
            resp = requests.get(f"{RESEARCH_URL}/ai/gene",
                                 params={"name": gene}, timeout=10)
            result = resp.json()
            return jsonify({
                "content": [{
                    "type": "text",
                    "text": (
                        f"Gene: {result.get('gene')}\n"
                        f"Records containing it: {result.get('records_containing_gene')}\n"
                        f"Risk scores: {result.get('risk_scores')}\n"
                        f"Explanation: {result.get('ai_explanation')}"
                    )
                }]
            })

        elif tool_name == "get_research_summary":
            resp = requests.get(f"{RESEARCH_URL}/ai/summary", timeout=15)
            result = resp.json()
            return jsonify({
                "content": [{
                    "type": "text",
                    "text": (
                        f"Summary: {result.get('ai_summary', '')}\n\n"
                        f"Grounding: {result.get('grounding', {}).get('overall_status')}\n"
                        f"Raw data: {json.dumps(result.get('raw_data', {}), indent=2)}"
                    )
                }]
            })

        elif tool_name == "beacon_query":
            gene = tool_input.get("gene", "")
            provider = tool_input.get("provider_url", "http://localhost:7001")
            resp = requests.get(f"{provider}/beacon/query",
                                 params={"gene": gene}, timeout=10)
            result = resp.json()
            return jsonify({
                "content": [{
                    "type": "text",
                    "text": (
                        f"Gene '{gene}' in {result.get('beaconId', provider)}:\n"
                        f"  Exists: {result.get('exists')}\n"
                        f"  Count: {result.get('count')}\n"
                        f"  Note: {result.get('note', '')}"
                    )
                }]
            })

        elif tool_name == "get_chain_state":
            resp = requests.get(f"{NODE_URL}/chain", timeout=5)
            chain_data = resp.json()
            valid_resp = requests.get(f"{NODE_URL}/validate", timeout=5)
            return jsonify({
                "content": [{
                    "type": "text",
                    "text": (
                        f"Chain length: {chain_data.get('length')} blocks\n"
                        f"Tip hash: {chain_data['chain'][-1]['hash'][:20]}...\n"
                        f"Valid: {valid_resp.json().get('valid')}"
                    )
                }]
            })

        else:
            return jsonify({"error": f"Unknown tool: {tool_name}"}), 404

    except requests.RequestException as e:
        return jsonify({"error": f"Could not reach backend service: {e}"}), 502


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--node-url", type=str, default="http://localhost:5001")
    parser.add_argument("--research-url", type=str, default="http://localhost:5050")
    args = parser.parse_args()
    NODE_URL = args.node_url
    RESEARCH_URL = args.research_url
    print(f"MCP server on port {args.port}")
    print(f"  -> blockchain node: {NODE_URL}")
    print(f"  -> research API:    {RESEARCH_URL}")
    print(f"  Tools: {[t['name'] for t in MCP_TOOLS]}")
    app.run(host="0.0.0.0", port=args.port)
