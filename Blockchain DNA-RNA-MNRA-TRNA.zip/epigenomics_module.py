"""
Epigenomics module — DNA methylation, RNA modifications, tRNA chemical changes.

WHAT THIS COVERS:
  1. DNA methylation (5mC, 5hmC)   — CpG site methylation already in dementia module
  2. mRNA m6A modification         — most abundant reversible RNA epigenetic mark
  3. m5C RNA methylation           — cytosine methylation in mRNA and tRNA
  4. Pseudouridine (Ψ)             — the 'fifth nucleotide', in mRNA/tRNA/rRNA/lncRNA
  5. tRNA wobble modifications      — mcm5s2U, m1G, ALKBH8 pathway
  6. A-to-I RNA editing            — adenosine-to-inosine deamination
  7. lncRNA regulation via m6A     — non-coding RNA epigenetic control
  8. Histone modifications         — H3K4me3, H3K27me3 (mark active/silenced genes)

REAL RESEARCH GROUNDING:
  m6A writers:  METTL3, METTL14, WTAP, VIRMA, RBM15, ZC3H13
  m6A erasers:  FTO (fat mass & obesity associated), ALKBH5
  m6A readers:  YTHDF1/2/3, YTHDC1/2, IGF2BP1/2/3
  Source: Molecular Biomedicine Springer Nature Sep 2025 (doi:10.1186/s43556-025-00314-2)
          MDPI Molecules Oct 2025; Signal Transduction & Targeted Therapy Nature 2021

  Pseudouridine (Ψ):
  'Fifth nucleotide' — most abundant RNA modification after m6A.
  Present in mRNA, tRNA (positions 38/39), rRNA, snRNA, lncRNA.
  Abnormal Ψ linked to breast cancer, colorectal cancer, liver cancer, NSCLC.
  Source: PMC11746961 (Clinical & Translational Medicine Jan 2025)
          PMC11683142 (Frontiers Immunology / Cell Death & Disease 2024)

  tRNA wobble modifications (mcm5s2U):
  ALKBH8 methylates wobble uridines in tRNA-Sec, tRNA-Glu, tRNA-Arg, tRNA-Gly.
  Loss disrupts selenoprotein synthesis, DNA repair, oxidative stress response.
  m1G methylation in mitochondrial tRNA: altered in tumour tissue.
  Source: Nature Cell Death & Disease Jan 2026 doi:10.1038/s41419-025-08234-3
          BioRxiv ALKBH8 2023; ACS Pharmacology & Translational Science Mar 2026

  Cancer connections:
  METTL3 upregulated in BRCA1-mutant breast/ovarian, ESCC, hepatocellular, AML.
  FTO (m6A eraser) drives melanoma (CDKN2A pathway), AML, NSCLC.
  ALKBH5 (m6A eraser) promotes glioblastoma stem cell self-renewal.
  YTHDF2 suppresses EGFR mRNA in hepatocellular carcinoma.
  FTO demethylates LINC00022 lncRNA → p21 degradation → cell cycle acceleration.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Any

import requests


# ── RNA modification types ──────────────────────────────────────────────────

@dataclass
class RNAModification:
    """A specific chemical modification on an RNA molecule."""
    modification_type:  str   # m6A, m5C, pseudouridine, m1A, A-to-I, m1G
    rna_class:          str   # mRNA, tRNA, rRNA, lncRNA, snRNA
    gene_or_transcript: str   # gene name or transcript ID
    position:           str   # genomic or transcript position / region
    writer_enzyme:      str   # enzyme that installs the modification
    eraser_enzyme:      str   # enzyme that removes it (if reversible)
    reader_protein:     str   # protein that recognises the mark
    cancer_connection:  str   # which cancer / mechanism this links to
    functional_effect:  str   # what the modification does functionally
    source:             str   # published literature source


@dataclass
class EpigenomicProfile:
    """Complete epigenomic profile for a gene or patient context."""
    sample_id:               str
    gene:                    str
    cancer_type:             str
    dna_methylation_sites:   List[Dict[str, Any]] = field(default_factory=list)
    rna_modifications:       List[RNAModification] = field(default_factory=list)
    histone_marks:           List[Dict[str, Any]] = field(default_factory=list)
    trna_modifications:      List[Dict[str, Any]] = field(default_factory=list)
    lncrna_regulation:       List[Dict[str, Any]] = field(default_factory=list)
    computed_at:             float = field(default_factory=time.time)

    def risk_from_epigenome(self) -> float:
        """
        Aggregate epigenomic risk score: more dysregulated marks = higher risk.
        Not a clinical diagnostic — a research pattern score.
        """
        score = 0.0
        # DNA methylation at cancer-associated CpG sites
        score += len(self.dna_methylation_sites) * 0.05
        # Each oncogenic RNA modification
        score += sum(0.08 for m in self.rna_modifications
                     if "oncogenic" in m.functional_effect.lower() or
                        "promote" in m.functional_effect.lower())
        # Silencing marks at tumour suppressors
        score += sum(0.12 for h in self.histone_marks
                     if h.get("mark") in ("H3K27me3", "H3K9me3"))
        # tRNA wobble disruption
        score += len(self.trna_modifications) * 0.04
        return round(min(score / (1 + score), 0.99), 4)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["epigenomic_risk_score"] = self.risk_from_epigenome()
        return d


# ── Real, grounded modification libraries ───────────────────────────────────

MRNA_M6A_MODIFICATIONS = [
    RNAModification(
        modification_type="m6A", rna_class="mRNA",
        gene_or_transcript="METTL3",
        position="3'-UTR and near stop codons (consensus RRACH motif)",
        writer_enzyme="METTL3-METTL14-WTAP complex",
        eraser_enzyme="FTO, ALKBH5",
        reader_protein="YTHDF2",
        cancer_connection="METTL3 upregulated in BRCA1-mutant breast cancer, AML, ESCC, hepatocellular carcinoma. YTHDF2 suppresses EGFR mRNA in HCC.",
        functional_effect="Regulates mRNA stability, splicing, export, translation — oncogenic when METTL3 overexpressed, promotes proliferation and drug resistance.",
        source="Molecular Biomedicine Springer Nature Sep 2025; Wiley MedComm Oct 2024",
    ),
    RNAModification(
        modification_type="m6A", rna_class="mRNA",
        gene_or_transcript="FTO-target transcripts",
        position="intron regions, alternative splicing exons, poly(A) sites",
        writer_enzyme="METTL3-METTL14-WTAP",
        eraser_enzyme="FTO (fat mass & obesity associated gene)",
        reader_protein="YTHDF1/3",
        cancer_connection="FTO upregulated in melanoma (CDKN2A pathway), AML, NSCLC. FTO promotes ESCC metastasis by demethylating LINC00022 lncRNA → p21 ubiquitination → cell cycle acceleration.",
        functional_effect="FTO demethylation removes m6A, stabilising oncogenic transcripts and destabilising tumour suppressor mRNAs. FTO SNPs strongly associated with increased cancer risk across multiple tumour types.",
        source="ACS Pharmacology & Translational Science Mar 2026; Frontiers Genetics 2025",
    ),
    RNAModification(
        modification_type="m6A", rna_class="mRNA",
        gene_or_transcript="APC (adenomatous polyposis coli)",
        position="3'-UTR — m6A on APC mRNA",
        writer_enzyme="METTL3 (recruits YTHDF)",
        eraser_enzyme="FTO",
        reader_protein="YTHDF — facilitates APC mRNA degradation",
        cancer_connection="In ESCC: METTL3 enhances m6A on APC mRNA, recruiting YTHDF to degrade it. Reduces APC expression, increases β-catenin/cyclin D1/c-Myc/PKM2, driving glycolysis, proliferation, metastasis.",
        functional_effect="m6A-mediated APC mRNA destabilisation activates WNT/β-catenin pathway — core oncogenic driver in colorectal and oesophageal cancers (MLH1 Lynch syndrome context).",
        source="Frontiers Genetics 2025 doi:10.3389/fgene.2025.1561799",
    ),
    RNAModification(
        modification_type="m6A", rna_class="lncRNA",
        gene_or_transcript="LINC00022",
        position="m6A sites in LINC00022 transcript",
        writer_enzyme="METTL3",
        eraser_enzyme="FTO (demethylates — promotes degradation resistance)",
        reader_protein="YTHDF2 (when m6A-marked, YTHDF2 degrades it)",
        cancer_connection="FTO demethylates LINC00022 in ESCC, preventing YTHDF2-mediated degradation. Stabilised LINC00022 binds p21 protein, promoting its ubiquitin-mediated degradation → cell cycle S-phase entry.",
        functional_effect="lncRNA epigenetic control: m6A modification determines LINC00022 fate. When FTO is overexpressed (cancer), LINC00022 stabilises → p21 lost → CDK2/4/6 unchecked.",
        source="Frontiers Genetics 2025; International Journal of Biological Sciences 2025 PALB2/pancreatic context",
    ),
]

TRNA_MODIFICATIONS = [
    {
        "modification": "mcm5s2U (5-methoxycarbonylmethyl-2-thiouridine)",
        "position": "Wobble position 34 of tRNA anticodon loop",
        "enzyme": "ALKBH8 (mammalian tRNA wobble uridine methyltransferase)",
        "affected_trnas": "tRNA-Sec (UGA), tRNA-Glu (UUC), tRNA-Arg (UCU), tRNA-Gly (UCC)",
        "function": "Ensures precise codon-anticodon base pairing, reading frame maintenance, and selenoprotein synthesis via tRNA-Sec recoding at UGA codons.",
        "disease_link": "ALKBH8 overexpressed in bladder cancer (silencing suppresses invasion, angiogenesis). Loss disrupts DNA repair, oxidative stress response, mitochondrial activity. ALKBH8 regulates selenoprotein synthesis critical for redox homeostasis.",
        "cancer_genes_affected": ["BRCA1","CDKN2A"],
        "source": "Nature Cell Death & Disease Jan 2026; BioRxiv ALKBH8 Nov 2023",
    },
    {
        "modification": "m1G (N1-methylguanosine)",
        "position": "Mitochondrial tRNA position 9 and 37",
        "enzyme": "TRMT10C / SDR5C1 (mitochondrial tRNA methyltransferase complex)",
        "affected_trnas": "Multiple mitochondrial tRNAs",
        "function": "Required for mitochondrial tRNA stability and proper mitochondrial translation. m1G at position 9 stabilises the tertiary structure of mitochondrial tRNAs.",
        "disease_link": "m1G methylation level significantly altered in tumour tissue vs normal. Abnormal m1G modification closely related to tumour occurrence and development. Expected biomarker or therapeutic target in tumour research.",
        "cancer_genes_affected": ["MLH1","BRCA1"],
        "source": "Nature Cell Death & Disease Jan 2026 doi:10.1038/s41419-025-08234-3",
    },
    {
        "modification": "Pseudouridine Ψ (position 38/39)",
        "position": "tRNA anticodon stem-loop positions 38 and 39",
        "enzyme": "PUS7 (pseudouridine synthase 7) — Deg1 equivalent in yeast",
        "affected_trnas": "Multiple cytoplasmic tRNAs; affects tRNA-Gln isoacceptors",
        "function": "Ψ modification enhances thermodynamic stability of tRNA (Ψ:A pair more stable than U:A). Absence of Ψ38/39 increases +1 translational frameshifting errors and reduces protein synthesis fidelity.",
        "disease_link": "Pseudouridylation imbalance causes pathogenesis: breast cancer (Montanaro 2006), colorectal cancer, NSCLC, liver cancer, gastric cancer. Ψ called the 'fifth nucleotide' due to regulatory ubiquity in mRNA/tRNA/rRNA/snRNA/lncRNA.",
        "cancer_genes_affected": ["BRCA1","BRCA2","MLH1"],
        "source": "PMC11683142 Cell Death & Disease 2024; PMC11746961 Clinical & Translational Medicine Jan 2025",
    },
    {
        "modification": "m5C (5-methylcytosine in tRNA)",
        "position": "tRNA positions 34, 38, 48, 49, 72",
        "enzyme": "NSUN2 (NOP2/Sun RNA Methyltransferase 2)",
        "affected_trnas": "tRNA-Asp, tRNA-Gly, tRNA-Val and others",
        "function": "m5C on tRNA stabilises tertiary structure and regulates translation efficiency. NSUN2 loss increases tRNA cleavage and stress-induced tRNA-derived small RNAs (tsRNAs).",
        "disease_link": "NSUN2 overexpressed in breast cancer, hepatocellular carcinoma. m5C on tRNA regulates codon-biased translation of oncoproteins. In ACS Pharmacology 2026 review: m5C affects RNA stability and translation.",
        "cancer_genes_affected": ["BRCA1","BRCA2"],
        "source": "ACS Pharmacology & Translational Science Mar 2026; Nature Structural Molecular Biology 2012",
    },
]

HISTONE_MARKS = [
    {
        "mark": "H3K4me3",
        "enzyme_writer": "KMT2A (MLL1), KMT2D",
        "enzyme_eraser": "KDM5A/B (JARID1A/B)",
        "effect": "Active transcription mark — found at gene promoters of actively transcribed genes",
        "cancer_link": "H3K4me3 loss at BRCA1 promoter in triple-negative breast cancer. KMT2D mutation common in MLH1-deficient colorectal cancers.",
        "genes": ["BRCA1","MLH1"],
    },
    {
        "mark": "H3K27me3",
        "enzyme_writer": "PRC2 complex (EZH2)",
        "enzyme_eraser": "KDM6A (UTX), KDM6B (JMJD3)",
        "effect": "Silencing mark — polycomb-mediated repression of tumour suppressors and developmental genes",
        "cancer_link": "EZH2 overexpression silences CDKN2A/p16 via H3K27me3 — epigenetic alternative to CDKN2A deletion in melanoma. Also silences MLH1 in sporadic CRC (alongside promoter methylation).",
        "genes": ["CDKN2A","MLH1","BRCA1"],
    },
    {
        "mark": "H3K9me3",
        "enzyme_writer": "SETDB1, SUV39H1/2",
        "enzyme_eraser": "KDM3A, KDM4A/B/C",
        "effect": "Constitutive heterochromatin silencing mark — silences repetitive elements and pericentromeric regions",
        "cancer_link": "H3K9me3 at BRCA1 regulatory regions in BRCA1-methylated sporadic breast cancer. SETDB1 amplified in melanoma, contributing to CDKN2A silencing beyond deletion.",
        "genes": ["BRCA1","CDKN2A"],
    },
    {
        "mark": "H3K36me3",
        "enzyme_writer": "SETD2",
        "enzyme_eraser": "KDM4A",
        "effect": "Elongation mark — deposited across gene bodies during active transcription, required for mismatch repair recruitment",
        "cancer_link": "SETD2 mutation causes H3K36me3 loss, impairing MMR recruitment to replication forks — directly relevant to MLH1/Lynch syndrome. H3K36me3 recruits MutSα to replication forks for mismatch repair.",
        "genes": ["MLH1","BRCA1"],
    },
]


def build_epigenomic_profile(gene: str, cancer_type: str,
                              sample_id: str) -> EpigenomicProfile:
    """
    Build a real, grounded epigenomic profile for a given gene and cancer type.
    Selects relevant modifications from the published literature databases above.
    """
    profile = EpigenomicProfile(
        sample_id=sample_id,
        gene=gene,
        cancer_type=cancer_type,
    )

    # RNA modifications relevant to this gene
    for mod in MRNA_M6A_MODIFICATIONS:
        if gene in mod.cancer_connection or gene in mod.gene_or_transcript:
            profile.rna_modifications.append(mod)

    # tRNA modifications relevant to this gene
    for tmod in TRNA_MODIFICATIONS:
        if gene in tmod.get("cancer_genes_affected", []):
            profile.trna_modifications.append(tmod)

    # Histone marks relevant to this gene
    for hmark in HISTONE_MARKS:
        if gene in hmark.get("genes", []):
            profile.histone_marks.append(hmark)

    # DNA methylation from existing dementia module markers (if relevant)
    if gene in ("MLH1",):
        profile.dna_methylation_sites.append({
            "site": "MLH1 promoter CpG island",
            "modification": "5-methylcytosine (5mC)",
            "effect": "Transcriptional silencing — sporadic MSI-H CRC. ORR to pembrolizumab 44% (sporadic methylated) vs 100% (germline Lynch).",
            "enzyme": "DNMT3A/B (de novo methylation)",
            "source": "PMC9465821 — Phase II pembrolizumab trial"
        })
    if gene in ("BRCA1",):
        profile.dna_methylation_sites.append({
            "site": "BRCA1 promoter CpG island",
            "modification": "5-methylcytosine (5mC) — sporadic breast cancer",
            "effect": "BRCA1 silencing without germline mutation in 10-15% of sporadic triple-negative breast cancer. Creates 'BRCAness' phenotype responsive to PARP inhibitors.",
            "enzyme": "DNMT1/3A/3B (maintenance + de novo)",
            "source": "ASCO 2024; OlympiA 6-year follow-up data"
        })
    if gene in ("CDKN2A",):
        profile.dna_methylation_sites.append({
            "site": "CDKN2A/p16 promoter CpG island",
            "modification": "5-methylcytosine (5mC) — epigenetic silencing",
            "effect": "CDKN2A promoter methylation is the most common epigenetic alteration in human cancer — found in ~40% of all tumour types. Silences p16 without deletion.",
            "enzyme": "DNMT3B (preferential); PRC2-mediated H3K27me3 precedes methylation",
            "source": "Cancer Research; PMC12776930 CDK4/6 review Nov 2025"
        })

    return profile


def mine_epigenomic_profile(profile: EpigenomicProfile,
                             node_url: str = "http://localhost:5001") -> Dict[str, Any]:
    """
    Mine the epigenomic profile to the blockchain.
    Only hashes of sensitive details go on-chain.
    Aggregate modification counts and risk scores are the on-chain payload.
    """
    payload = {
        "event":              "epigenomic_profile",
        "gene":               profile.gene,
        "cancer_type":        profile.cancer_type,
        "sample_id_hash":     hashlib.sha256(profile.sample_id.encode()).hexdigest()[:20],
        # Counts only — no raw modification sequences
        "rna_mod_count":      len(profile.rna_modifications),
        "dna_met_sites":      len(profile.dna_methylation_sites),
        "histone_marks":      len(profile.histone_marks),
        "trna_mod_count":     len(profile.trna_modifications),
        "epigenomic_risk":    profile.risk_from_epigenome(),
        # Hash of full detail (stored off-chain)
        "profile_hash":       hashlib.sha256(
            json.dumps(profile.to_dict(), sort_keys=True, default=str).encode()
        ).hexdigest()[:24],
        "data_sources_used":  list({
            m.source.split(";")[0].strip()
            for m in profile.rna_modifications
        })[:3],
        "timestamp": time.time(),
    }
    resp = requests.post(f"{node_url}/mutations", json=payload, timeout=30)
    block = resp.json()["block"]
    return {"block": block, "payload": payload, "profile": profile.to_dict()}


if __name__ == "__main__":
    print("=== Epigenomics Module — Demo ===\n")
    for gene, cancer in [("BRCA1","Breast/Ovarian"),("MLH1","Colorectal"),("CDKN2A","Melanoma")]:
        profile = build_epigenomic_profile(gene, cancer, f"sample-{gene}-001")
        print(f"{gene} ({cancer})")
        print(f"  DNA methylation sites: {len(profile.dna_methylation_sites)}")
        print(f"  RNA modifications:     {len(profile.rna_modifications)}")
        print(f"  Histone marks:         {len(profile.histone_marks)}")
        print(f"  tRNA modifications:    {len(profile.trna_modifications)}")
        print(f"  Epigenomic risk score: {profile.risk_from_epigenome()}")
        print()
