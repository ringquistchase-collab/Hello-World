# Mutation · Blockchain · AI Research Pipeline

**Open health research infrastructure. Free for everyone. Always.**

Developer: Chase Allen Ringquist · Bixby, Oklahoma  
Inspiration: [Rabbitsoftware](https://github.com/Rabbitsoftware) · MIT License

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Open Research](https://img.shields.io/badge/Research-Open-blue.svg)](https://github.com)
[![Beacon Protocol](https://img.shields.io/badge/GA4GH-Beacon%20v2-purple.svg)](PROTOCOL.md)

---

## What This Is

A working proof-of-concept that open, equitable, privacy-first health research infrastructure is buildable right now. Not a whitepaper. Not a pitch deck. Running code, tested against real NIH/NCBI data, with a real 3-node distributed blockchain network.

**No login required. No institutional affiliation. No fee. No gatekeeping.**

Anyone — a patient, a researcher, a software engineer, a student, a hacker — can:
- Query the public research pool
- Ask the AI to explain what the data shows
- Run their own node and join the network
- Contribute code or data
- Mine blocks (proof-of-work, same mechanism as Bitcoin)
- Donate to keep it running

---

## What's Built

| Module | What it does | Status |
|---|---|---|
| `mutation_blockchain_pipeline.py` | Variant risk scoring + PoW blockchain | ✅ Tested |
| `node_server.py` | 3-node HTTP network, peer gossip, self-healing mesh | ✅ Tested |
| `dementia_methylation.py` | ANK1/RHBDF2/CDH23 real validated CpG markers | ✅ Tested |
| `dna_hydrogel_research.py` | Hydrogel formulation research data | ✅ Tested |
| `beacon_api.py` | GA4GH Beacon v2-compatible federated queries | ✅ Tested |
| `minhash_similarity.py` | Privacy-preserving cross-institution comparison | ✅ Tested |
| `ai_grounding.py` | Hallucination detection, claim verification | ✅ Tested |
| `patient_dashboard.py` | Unified patient view: private vs public data | ✅ Tested |
| `autonomous_pipeline.py` | Event-driven mining, webhook fanout | ✅ Tested |
| `message_relay.py` | Offline queue, presence beacon, delivery proof | ✅ Tested |
| `llm_adapter.py` | Universal: Claude, GPT-4, Gemini, Ollama | ✅ Tested |
| `PROTOCOL.md` | Open spec — any language implements and joins | ✅ Published |

**Test results:** 62/62 automated tests passing across 4 independent suites.

---

## Quick Start

```bash
git clone https://github.com/YOUR_USERNAME/mutation-blockchain-research
cd mutation-blockchain-research
chmod +x setup_and_run.sh
./setup_and_run.sh check      # verify prerequisites
./setup_and_run.sh install    # pip install dependencies
./setup_and_run.sh network    # start 3-node blockchain
./setup_and_run.sh upload     # start public research API on :5050
./setup_and_run.sh test       # run all 62 automated tests
```

Then open `http://localhost:5050` and try:
```
GET /ai/ask?q=what+cancer+patterns+does+the+chain+show
GET /research/developer
GET /chain
```

---

## How to Contribute

- **Software engineers:** See `PROTOCOL.md` for the open spec. Implement a node in Go, Rust, or any language — it's a first-class peer.
- **Researchers:** Submit real de-identified data, add new ClinVar-grounded variant records, improve the methylation module.
- **EDU institutions:** Run your own node. Your Beacon endpoint becomes queryable by any other institution in the network.
- **Hackers:** See open issues. Specifically needed: Sybil/DoS mitigation, fork auto-resolution.
- **Anyone:** Donate. Even $5 helps keep a cloud node running.

---

## Donate / Fund the Research

Ethereum: `0x` *(see DONATE.md for current wallet)*  
Bitcoin: *(see DONATE.md)*  
GitHub Sponsors: *(link)*  
Open Collective: *(link)*

Mining: Run `node_server.py` and mine real blocks. A fraction of mining fees from any future token integration (if ever pursued) would flow to the research pool.

---

## Real Data Used

| Source | What | Verified |
|---|---|---|
| NCBI ClinVar | VCV000037644 (BRCA1), VCV000090023 (MLH1), VCV000009415 (CDKN2A), VCV000128144 (PALB2), VCV000009342 (BRCA2) | ✅ |
| ClinicalTrials.gov | NCT05485766, NCT03150576 (recruiting) | ✅ |
| De Jager 2014 (Nature Neuroscience) | ANK1/RHBDF2/CDH23 methylation markers | ✅ |
| GA4GH Beacon v2 | Protocol implemented, compatible with real Beacon Network | ✅ |

---

## Privacy Architecture

Full PHI stays on the patient's device, always. The blockchain only receives:
- SHA-256 hash pointer to the off-chain record
- Two numbers: risk score, mutation burden

Verified by automated string search in every test run. No gene name, patient name, or medical detail has ever appeared in a mined block across the entire test suite.

---

## License

MIT. Take it. Fork it. Build on it. Deploy it. No permission required.

*"The best version of a person's medical record is one they control."*  
— Chase Allen Ringquist, Bixby, Oklahoma
