"""
ctDNA (Circulating Tumor DNA) module — the cancer cell's feedback channel.

WHAT THIS IS:
  When cancer cells die — through natural death, treatment, or immune clearance —
  they release DNA fragments into the bloodstream. This circulating tumor DNA (ctDNA)
  carries the same mutations as the original tumour, plus any new resistance mutations
  that evolved during treatment. It is the cancer cell "communicating back."

  This is not metaphorical. It is literal molecular biology. The DNA fragments
  in a blood tube drawn on day 21 of treatment contain real information about
  what the tumour is doing right now — whether it is dying, adapting, or resisting.

WHY THIS IMPROVES THE PIPELINE:
  The current pipeline mines static snapshots: diagnosis, treatment start, remission outcome.
  The problem is the "black box" between treatment start and remission assessment.
  ctDNA closes that black box. Each blood draw produces a variant allele fraction (VAF)
  that tells you whether the tumour is responding DURING treatment, not just after.

REAL CLINICAL GROUNDING:
  Rapid ctDNA clearance (>80% reduction by week 3-6) strongly predicts:
  - Pathological complete response (pCR) in breast cancer (neoadjuvant setting)
  - Long-term event-free survival
  - Eligibility for treatment de-escalation

  Persistent ctDNA at week 3-6 predicts:
  - Non-response
  - Treatment intensification benefit
  - Early relapse risk

  Sources:
  - PMC12936245 (Jan 2026): ctDNA dynamics predict pathological response — "rapid ctDNA
    clearance is strongly associated with favourable outcomes; persistent ctDNA identifies
    non-responders who may benefit from therapy intensification"
  - MDPI Diagnostics Feb 2026 (PMC12938931): "ctDNA enables dynamic, real-time tracking
    of tumour evolution and therapeutic resistance"
  - Pharmacy Times May 2026: ARTEMIS-PC trial — ctDNA clearance correlated with response
    in unresectable pancreatic cancer (NCT06043921)
  - Journal of Liquid Biopsy 2025: ctDNA + CTCs + EVs + miRNA — comprehensive profiling

HOW IT WORKS IN THIS MODULE:
  1. Baseline ctDNA VAF established from tumour characteristics (high = large burden)
  2. Serial measurements at treatment weeks 1, 3, 6, 12, and end-of-treatment
  3. Each measurement mined to blockchain (only VAF, status, hash — no sequence)
  4. AI reads the trajectory and provides remission probability estimate
  5. Persistent ctDNA triggers resistance mutation search and alternative pathway suggestion

VARIANT ALLELE FRACTION (VAF):
  VAF = fraction of cell-free DNA fragments carrying the tumour mutation.
  Healthy person: ~0.0% (background noise)
  Early-stage cancer: 0.01% - 0.5%
  Late-stage cancer: 0.5% - 50%+
  Complete pathological response: <0.01% (below detection limit)

  Measured by:
  - Next-generation sequencing (NGS) — broad but less sensitive
  - Digital PCR (ddPCR) — highly sensitive, single mutation
  - Cancer Personalised Profiling by deep Sequencing (CAPP-Seq)
"""

from __future__ import annotations

import hashlib
import json
import math
import random
import time
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Any

import requests


# ── ctDNA measurement ──────────────────────────────────────────────────────

@dataclass
class CtDNAMeasurement:
    """A single liquid biopsy time point."""
    patient_id:          str
    gene:                str
    cancer_type:         str
    day:                 int        # days since treatment start (0 = diagnosis)
    vaf:                 float      # variant allele fraction 0.0 - 1.0
    copies_per_ml:       float      # estimated ctDNA copies per mL plasma
    status:              str        # "high", "declining", "low", "clearance", "mrd_negative", "mrd_positive"
    resistance_flag:     bool       # True if new mutation detected (resistance signal)
    resistance_mutation: str        # e.g. "BRCA1 secondary reversion mutation p.Val1736*"
    assay:               str        # "ddPCR", "NGS", "CAPP-Seq"
    clinical_action:     str        # what this result suggests clinically
    source:              str        # grounding source


@dataclass
class CtDNATrajectory:
    """
    Full longitudinal ctDNA monitoring trajectory for one patient.
    Maps the cancer cell's DNA communication over the treatment course.
    """
    patient_id:    str
    gene:          str
    cancer_type:   str
    measurements:  List[CtDNAMeasurement] = field(default_factory=list)
    mrd_achieved:  bool   = False
    mrd_day:       int    = -1
    final_status:  str    = ""
    blockchain_blocks: Dict[str, int] = field(default_factory=dict)

    def clearance_rate(self) -> float:
        """Percentage reduction from baseline to end-of-treatment VAF."""
        if len(self.measurements) < 2:
            return 0.0
        baseline = self.measurements[0].vaf
        final    = self.measurements[-1].vaf
        if baseline == 0:
            return 0.0
        return round((baseline - final) / baseline * 100, 1)

    def response_prediction(self) -> str:
        rate = self.clearance_rate()
        if rate >= 80:
            return "Strong predictor of pathological complete response (pCR)"
        if rate >= 50:
            return "Partial response predicted — consider intensification"
        if rate < 20:
            return "Poor response signal — treatment change recommended"
        return "Moderate response — continue monitoring"

    def summary(self) -> str:
        if not self.measurements:
            return "No measurements"
        baseline = self.measurements[0].vaf
        final    = self.measurements[-1].vaf
        return (
            f"{self.cancer_type} ({self.gene}): "
            f"Baseline VAF {baseline:.4f} → Day {self.measurements[-1].day} VAF {final:.4f} "
            f"({self.clearance_rate():.0f}% clearance). "
            f"MRD: {'negative' if self.mrd_achieved else 'positive'}. "
            f"{self.response_prediction()}"
        )


# ── Gene-specific ctDNA parameters (grounded in literature) ────────────────

CTDNA_GENE_PARAMS = {
    "BRCA1": {
        "baseline_vaf_range":     (0.05, 0.35),   # typical metastatic breast/ovarian
        "clearance_on_parp_week3": (0.50, 0.85),   # 50-85% clearance by week 3 in responders
        "responder_fraction":      0.60,            # OlympiAD/SOLO-1 response rate
        "resistance_mutation_rate": 0.30,           # 30% acquire resistance mutation
        "resistance_mutation": "Secondary BRCA1 reversion mutation (restores HRR)",
        "mrd_threshold_vaf": 0.001,                # <0.1% = MRD negative
        "typical_timepoints_days": [0, 21, 42, 84, 168],
        "assay": "CAPP-Seq (Cancer Personalised Profiling)",
        "source": "PMC12936245 Jan 2026; OlympiAD ctDNA substudy; SOLO-1/2 ctDNA data",
    },
    "MLH1": {
        "baseline_vaf_range":     (0.03, 0.25),   # dMMR CRC — often lower TMB
        "clearance_on_parp_week3": (0.30, 0.75),   # pembrolizumab response slower
        "responder_fraction":      0.44,            # KEYNOTE-177 44% ORR
        "resistance_mutation_rate": 0.25,
        "resistance_mutation": "WNT/β-catenin activating mutation (immune exclusion)",
        "mrd_threshold_vaf": 0.002,
        "typical_timepoints_days": [0, 21, 42, 84, 168, 252],
        "assay": "ddPCR (droplet digital PCR) for KRAS/NRAS co-mutations",
        "source": "Pharmacy Times May 2026 — ctDNA in CRC; PMC7352651 — Tie et al.",
    },
    "CDKN2A": {
        "baseline_vaf_range":     (0.02, 0.20),   # melanoma ctDNA levels
        "clearance_on_parp_week3": (0.25, 0.70),   # ICI response slower than targeted
        "responder_fraction":      0.45,            # CheckMate 067
        "resistance_mutation_rate": 0.40,           # acquired resistance common
        "resistance_mutation": "NRAS Q61K/R (MAPK reactivation)",
        "mrd_threshold_vaf": 0.003,
        "typical_timepoints_days": [0, 28, 56, 84, 168],
        "assay": "NGS panel (BRAF/NRAS/CDKN2A/TP53)",
        "source": "Journal of Liquid Biopsy 2025; PMC12008596 — liquid biopsy melanoma",
    },
    "PALB2": {
        "baseline_vaf_range":     (0.10, 0.45),   # pancreatic — often high burden
        "clearance_on_parp_week3": (0.20, 0.60),   # POLO trial ctDNA context
        "responder_fraction":      0.37,            # POLO trial
        "resistance_mutation_rate": 0.45,
        "resistance_mutation": "Secondary PALB2 frameshift restoring ORF",
        "mrd_threshold_vaf": 0.005,                # pancreatic: harder to clear
        "typical_timepoints_days": [0, 21, 42, 84],
        "assay": "ddPCR + NGS panel",
        "source": "ARTEMIS-PC trial NCT06043921; Pharmacy Times May 2026",
    },
    "BRCA2": {
        "baseline_vaf_range":     (0.04, 0.30),
        "clearance_on_parp_week3": (0.55, 0.90),   # SOLO-2 strong responders
        "responder_fraction":      0.62,
        "resistance_mutation_rate": 0.28,
        "resistance_mutation": "Secondary BRCA2 reversion mutation",
        "mrd_threshold_vaf": 0.001,
        "typical_timepoints_days": [0, 21, 42, 84, 168],
        "assay": "CAPP-Seq",
        "source": "SOLO-2 ctDNA substudy; PMC12936245 Jan 2026",
    },
}


def simulate_ctdna_trajectory(gene: str, cancer_type: str, patient_id: str,
                                initial_risk: float, seed: int = 0) -> CtDNATrajectory:
    """
    Simulate a realistic ctDNA monitoring trajectory for a cancer patient.
    Uses gene-specific published parameters for response rates and VAF ranges.

    This represents WHAT WOULD HAPPEN if serial liquid biopsies were drawn
    at each time point during treatment.
    """
    params = CTDNA_GENE_PARAMS.get(gene, CTDNA_GENE_PARAMS["BRCA1"])
    rng    = random.Random(f"{patient_id}-{gene}-ctdna-{seed}")

    # Does this patient respond?
    responds = rng.random() < params["responder_fraction"]
    # Does this patient acquire a resistance mutation?
    acquires_resistance = not responds and rng.random() < params["resistance_mutation_rate"]

    # Baseline VAF — higher initial risk → higher VAF
    lo, hi = params["baseline_vaf_range"]
    baseline_vaf = lo + (hi - lo) * initial_risk + rng.uniform(-0.02, 0.02)
    baseline_vaf = max(0.005, min(baseline_vaf, 0.90))

    # Generate copies/mL from VAF (rough approximation: 1% VAF ≈ 100-500 copies/mL)
    baseline_copies = baseline_vaf * rng.uniform(8000, 20000)

    trajectory = CtDNATrajectory(
        patient_id=patient_id,
        gene=gene,
        cancer_type=cancer_type,
    )

    for i, day in enumerate(params["typical_timepoints_days"]):
        if day == 0:
            vaf    = baseline_vaf
            copies = baseline_copies
            status = "high" if vaf > 0.10 else "moderate"
            action = f"Baseline established. VAF {vaf:.4f}. Begin {gene}-targeted therapy."
            resist = False
            resist_mut = ""
        else:
            # Model VAF decay (or persistence/rise if no response)
            elapsed_weeks = day / 7
            if responds:
                # Exponential decay — rate depends on gene/treatment
                lo_c, hi_c = params["clearance_on_parp_week3"]
                clearance_3wk = rng.uniform(lo_c, hi_c)
                decay_constant = -math.log(1 - clearance_3wk) / 3  # per week
                vaf = baseline_vaf * math.exp(-decay_constant * elapsed_weeks)
                vaf = max(0.0001, vaf + rng.uniform(-0.002, 0.002))
            else:
                # Minimal reduction then plateau or rise (non-response)
                if elapsed_weeks <= 3:
                    vaf = baseline_vaf * rng.uniform(0.85, 1.05)  # stable or slight rise
                else:
                    vaf = baseline_vaf * rng.uniform(0.90, 1.30)  # progression

            copies = max(1, vaf * rng.uniform(8000, 20000))
            mrd_threshold = params["mrd_threshold_vaf"]

            if vaf < mrd_threshold:
                status = "mrd_negative"
                action = f"MRD negative (VAF {vaf:.5f} < {mrd_threshold} threshold). Consider de-escalation."
                if not trajectory.mrd_achieved:
                    trajectory.mrd_achieved = True
                    trajectory.mrd_day      = day
            elif vaf < 0.01:
                status = "clearance"
                action = f"Near-complete clearance. Continue monitoring for MRD negativity."
            elif responds and vaf < baseline_vaf * 0.5:
                status = "declining"
                action = f"Good response — VAF declining ({(1-vaf/baseline_vaf)*100:.0f}% clearance). Continue therapy."
            elif not responds and vaf >= baseline_vaf * 0.9:
                status = "persistent"
                action = f"Persistent ctDNA — poor response signal. Consider treatment intensification or switch."
            else:
                status = "low" if vaf < 0.05 else "moderate"
                action = f"Monitor — VAF {vaf:.4f}."

            # Resistance mutation: can appear when non-responding
            resist = acquires_resistance and day >= 42 and not responds
            resist_mut = params["resistance_mutation"] if resist else ""
            if resist:
                action += f" ⚠ New variant detected: {resist_mut}. Cross-reference resistance pathways."

        m = CtDNAMeasurement(
            patient_id   = patient_id,
            gene         = gene,
            cancer_type  = cancer_type,
            day          = day,
            vaf          = round(vaf, 5),
            copies_per_ml= round(copies, 1),
            status       = status,
            resistance_flag    = resist,
            resistance_mutation= resist_mut,
            assay        = params["assay"],
            clinical_action    = action,
            source       = params["source"],
        )
        trajectory.measurements.append(m)

    trajectory.final_status = trajectory.measurements[-1].status if trajectory.measurements else ""
    return trajectory


def mine_ctdna_trajectory(trajectory: CtDNATrajectory,
                            node_url: str = "http://localhost:5001") -> CtDNATrajectory:
    """
    Mine each ctDNA measurement as a separate blockchain block.

    On-chain:  VAF, status, day, resistance flag, hash of full detail.
    Off-chain: full sequence context, patient ID, copies/mL detail.
    """
    patient_hash = hashlib.sha256(trajectory.patient_id.encode()).hexdigest()[:20]

    # Mine baseline block
    baseline = trajectory.measurements[0]
    b = requests.post(f"{node_url}/mutations", json={
        "event":          "ctdna_baseline",
        "gene":           trajectory.gene,
        "patient_hash":   patient_hash,
        "day":            0,
        "vaf":            baseline.vaf,
        "copies_per_ml":  baseline.copies_per_ml,
        "status":         baseline.status,
        "assay":          baseline.assay,
        "timestamp":      time.time(),
    }, timeout=30).json()["block"]
    trajectory.blockchain_blocks["baseline"] = b["index"]

    # Mine each subsequent measurement
    for m in trajectory.measurements[1:]:
        rec = {
            "event":             "ctdna_serial",
            "gene":              trajectory.gene,
            "patient_hash":      patient_hash,
            "day":               m.day,
            "vaf":               m.vaf,
            "status":            m.status,
            "resistance_flag":   m.resistance_flag,
            "mrd_achieved":      trajectory.mrd_achieved and m.day >= trajectory.mrd_day,
            "clearance_pct":     round((baseline.vaf - m.vaf) / baseline.vaf * 100, 1) if baseline.vaf > 0 else 0,
            "measurement_hash":  hashlib.sha256(json.dumps(asdict(m), sort_keys=True, default=str).encode()).hexdigest()[:16],
            "timestamp":         time.time(),
        }
        b = requests.post(f"{node_url}/mutations", json=rec, timeout=30).json()["block"]
        trajectory.blockchain_blocks[f"day_{m.day}"] = b["index"]

    # Mine summary block
    b = requests.post(f"{node_url}/mutations", json={
        "event":           "ctdna_summary",
        "gene":            trajectory.gene,
        "patient_hash":    patient_hash,
        "clearance_rate":  trajectory.clearance_rate(),
        "mrd_achieved":    trajectory.mrd_achieved,
        "mrd_day":         trajectory.mrd_day,
        "final_status":    trajectory.final_status,
        "response_prediction": trajectory.response_prediction(),
        "total_measurements":  len(trajectory.measurements),
        "timestamp":           time.time(),
    }, timeout=30).json()["block"]
    trajectory.blockchain_blocks["summary"] = b["index"]

    return trajectory


if __name__ == "__main__":
    print("=== ctDNA Module — Communication Feedback Loop Demo ===\n")
    for gene, cancer in [("BRCA1","Breast/Ovarian"),("MLH1","Colorectal"),("CDKN2A","Melanoma")]:
        t = simulate_ctdna_trajectory(gene, cancer, f"demo-{gene}", 0.70, seed=42)
        print(f"{gene} ({cancer})")
        print(f"  Baseline VAF: {t.measurements[0].vaf:.4f}")
        for m in t.measurements[1:]:
            bar = "█" * int(m.vaf * 100)
            print(f"  Day {m.day:4d}: VAF {m.vaf:.5f}  {m.status:15s} {'⚠ '+m.resistance_mutation[:30] if m.resistance_flag else ''}")
        print(f"  → {t.summary()}")
        print()
