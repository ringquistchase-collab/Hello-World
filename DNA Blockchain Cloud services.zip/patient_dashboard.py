"""
Patient dashboard: /patient route added to upload_app.py.

This adds four things the system currently lacks:
1. A unified view of everything belonging to one patient_id
   (on-chain records, off-chain bundle, timeline, research pool status)
2. Clear visual separation between what the NETWORK can see vs what
   only THIS PATIENT can see
3. Basic session token control (not production auth -- person_id is
   still free text, as documented throughout -- but the dashboard
   makes the access-control boundaries visible rather than implicit)
4. A plain-English explanation of each data category alongside the
   raw data, so a patient understands what they're looking at

TO INTEGRATE: add these routes to upload_app.py and import the
OffChainStore and PersonalTimeline at the top of that file.
"""

PATIENT_DASHBOARD_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Your Health Record</title>
<style>
  :root {
    --bg:       #0d1117;
    --surface:  #161b22;
    --card:     #21262d;
    --border:   #30363d;
    --text:     #e6edf3;
    --muted:    #8b949e;
    --accent:   #58a6ff;
    --green:    #3fb950;
    --amber:    #d29922;
    --red:      #f85149;
    --private:  #1f3a4a;
    --public:   #1a2e1a;
    --font:     -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    --mono:     "SF Mono", "Fira Code", monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: var(--font); font-size: 14px; line-height: 1.6; }
  .topbar { background: var(--surface); border-bottom: 1px solid var(--border); padding: 12px 24px;
    display: flex; align-items: center; justify-content: space-between; }
  .topbar-title { font-size: 15px; font-weight: 600; color: var(--text); }
  .patient-id { font-family: var(--mono); font-size: 12px; color: var(--muted);
    background: var(--card); border: 1px solid var(--border); padding: 4px 10px; border-radius: 20px; }
  .layout { display: grid; grid-template-columns: 220px 1fr; min-height: calc(100vh - 48px); }
  .sidebar { background: var(--surface); border-right: 1px solid var(--border); padding: 20px 0; }
  .sidebar a { display: flex; align-items: center; gap: 10px; padding: 9px 20px; color: var(--muted);
    text-decoration: none; font-size: 13px; transition: all .15s; }
  .sidebar a:hover, .sidebar a.active { color: var(--text); background: var(--card); }
  .sidebar a .dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
  .dot-private { background: var(--accent); }
  .dot-public { background: var(--green); }
  .dot-control { background: var(--amber); }
  .sidebar-section { font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
    color: var(--muted); padding: 16px 20px 6px; }
  .main { padding: 28px 32px; max-width: 900px; }
  h2 { font-size: 18px; font-weight: 600; margin-bottom: 4px; }
  .subtitle { color: var(--muted); font-size: 13px; margin-bottom: 20px; }
  .badge { display: inline-block; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 12px; }
  .badge-private { background: #1c3a5e; color: #79c0ff; }
  .badge-public  { background: #1a2e1a; color: #56d364; }
  .badge-permanent { background: #3d1a00; color: #f0883e; }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 8px;
    margin-bottom: 16px; overflow: hidden; }
  .card-header { padding: 14px 18px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between; }
  .card-header-title { font-weight: 600; font-size: 14px; }
  .card-body { padding: 16px 18px; }
  .explain { color: var(--muted); font-size: 13px; margin-bottom: 14px; line-height: 1.55; }
  .field-grid { display: grid; grid-template-columns: 160px 1fr; gap: 6px 12px; }
  .field-label { color: var(--muted); font-size: 12px; align-self: center; }
  .field-value { font-family: var(--mono); font-size: 12px; color: var(--text); word-break: break-all; }
  .hash { color: var(--accent); }
  .score-bar-wrap { background: var(--border); border-radius: 4px; height: 8px; width: 200px; overflow: hidden; }
  .score-bar { height: 100%; border-radius: 4px; background: linear-gradient(to right, var(--green), var(--amber), var(--red)); }
  .timeline-entry { border-left: 2px solid var(--border); padding: 0 0 18px 18px; position: relative; }
  .timeline-entry:last-child { padding-bottom: 0; }
  .timeline-dot { position: absolute; left: -5px; top: 3px; width: 8px; height: 8px;
    border-radius: 50%; background: var(--accent); border: 2px solid var(--bg); }
  .timeline-type { font-size: 11px; font-weight: 600; color: var(--accent); text-transform: uppercase;
    letter-spacing: .05em; margin-bottom: 2px; }
  .timeline-hash { font-family: var(--mono); font-size: 10px; color: var(--muted); }
  .consent-row { display: flex; align-items: center; justify-content: space-between;
    padding: 10px 0; border-bottom: 1px solid var(--border); }
  .consent-row:last-child { border-bottom: none; }
  .consent-name { font-size: 13px; }
  .consent-desc { font-size: 12px; color: var(--muted); }
  .pill { display: inline-block; font-size: 11px; padding: 2px 10px; border-radius: 12px;
    font-weight: 600; cursor: pointer; border: none; font-family: var(--font); }
  .pill-on { background: #1a2e1a; color: var(--green); }
  .pill-off { background: var(--card); color: var(--muted); border: 1px solid var(--border); }
  .layer-legend { display: flex; gap: 20px; margin-bottom: 20px; flex-wrap: wrap; }
  .layer-item { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--muted); }
  .layer-dot { width: 10px; height: 10px; border-radius: 50%; }
  form { display: contents; }
  .btn { padding: 7px 16px; border-radius: 6px; border: none; font-size: 13px; font-weight: 500;
    cursor: pointer; font-family: var(--font); }
  .btn-danger { background: #3d1a1a; color: var(--red); border: 1px solid #6e1c1c; }
  .btn-primary { background: #1a3050; color: var(--accent); border: 1px solid #2d5a9e; }
  .raw-block { background: var(--bg); border: 1px solid var(--border); border-radius: 6px;
    padding: 12px; font-family: var(--mono); font-size: 11px; color: var(--muted);
    white-space: pre-wrap; word-break: break-all; max-height: 240px; overflow-y: auto; }
  .notice { background: #1c2a1c; border: 1px solid #2d4a2d; border-radius: 6px;
    padding: 12px 16px; font-size: 13px; color: #56d364; margin-bottom: 20px; }
  .notice-warn { background: #2a1f10; border-color: #5a3a10; color: #d29922; }
  .section { margin-bottom: 32px; }
  .access-split { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
  @media (max-width: 680px) { .layout { grid-template-columns: 1fr; } .sidebar { display: none; }
    .access-split { grid-template-columns: 1fr; } }
</style>
</head>
<body>

<div class="topbar">
  <span class="topbar-title">Your Health Record</span>
  <span class="patient-id">{{ patient_id }}</span>
</div>

<div class="layout">
<nav class="sidebar">
  <div class="sidebar-section">Private (only you)</div>
  <a href="#full-record" class="active"><span class="dot dot-private"></span>Full record</a>
  <a href="#timeline"><span class="dot dot-private"></span>Timeline</a>

  <div class="sidebar-section">Shared (network)</div>
  <a href="#onchain"><span class="dot dot-public"></span>On-chain data</a>
  <a href="#research"><span class="dot dot-public"></span>Research pool</a>

  <div class="sidebar-section">Controls</div>
  <a href="#consent"><span class="dot dot-control"></span>Consent &amp; access</a>
  <a href="#understand"><span class="dot dot-control"></span>What this means</a>
</nav>

<main class="main">

  <!-- Orientation legend -->
  <div class="layer-legend">
    <div class="layer-item"><div class="layer-dot" style="background:var(--accent)"></div>Private — only on your device</div>
    <div class="layer-item"><div class="layer-dot" style="background:var(--green)"></div>Public — visible on the network</div>
    <div class="layer-item"><div class="layer-dot" style="background:var(--amber)"></div>Permanent — cannot be deleted once mined</div>
    <div class="layer-item"><div class="layer-dot" style="background:var(--red)"></div>Revocable — you can remove this any time</div>
  </div>

  <!-- Access split overview -->
  <div class="access-split">
    <div class="card">
      <div class="card-header">
        <span class="card-header-title">What only you can see</span>
        <span class="badge badge-private">Private</span>
      </div>
      <div class="card-body">
        <p class="explain">Your full medical history, family history, germline gene details, EEG data, and hormone values live only in <strong>offchain_store.json</strong> on this device. Nothing in this list has ever been transmitted to the network.</p>
        <div class="field-grid">
          <span class="field-label">Full bundle size</span>
          <span class="field-value">{{ bundle_size }} bytes</span>
          <span class="field-label">Off-chain entries</span>
          <span class="field-value">{{ offchain_count }}</span>
          <span class="field-label">Timeline entries</span>
          <span class="field-value">{{ timeline_count }}</span>
          <span class="field-label">Integrity</span>
          <span class="field-value" style="color:var(--green)">{{ integrity_status }}</span>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <span class="card-header-title">What the network can see</span>
        <span class="badge badge-public">Public</span>
      </div>
      <div class="card-body">
        <p class="explain">The blockchain stores only a hash pointer and two numbers. No name, no gene, no history. Verified by direct string search in every test run.</p>
        <div class="field-grid">
          <span class="field-label">On-chain records</span>
          <span class="field-value">{{ onchain_count }}</span>
          <span class="field-label">Network size</span>
          <span class="field-value">{{ onchain_size }} bytes ({{ onchain_pct }}% of full record)</span>
          <span class="field-label">PHI on-chain</span>
          <span class="field-value" style="color:var(--green)">None — confirmed</span>
          <span class="field-label">Deletable?</span>
          <span class="field-value" style="color:var(--red)">No — blockchain is permanent</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Full record -->
  <div class="section" id="full-record">
    <h2>Full record <span class="badge badge-private">Private</span></h2>
    <p class="subtitle">Everything stored about you. This page itself is the "patient view" — only accessible to whoever has your patient ID.</p>
    {% if bundle %}
    <div class="card">
      <div class="card-header">
        <span class="card-header-title">Risk summary</span>
      </div>
      <div class="card-body">
        <div class="field-grid" style="margin-bottom:14px">
          <span class="field-label">Adjusted risk score</span>
          <span class="field-value">
            {{ bundle.adjusted_risk_score }}
            <div class="score-bar-wrap" style="display:inline-block;vertical-align:middle;margin-left:10px">
              <div class="score-bar" style="width:{{ (bundle.adjusted_risk_score * 100)|int }}%"></div>
            </div>
          </span>
          <span class="field-label">Mutation burden</span>
          <span class="field-value">{{ bundle.trajectory.tumor_mutation_burden }} somatic variants</span>
          <span class="field-label">Genes affected</span>
          <span class="field-value">{{ bundle.trajectory.genes_affected | join(", ") }}</span>
          <span class="field-label">Family history factor</span>
          <span class="field-value">{{ bundle.family_history_factor }}×</span>
          <span class="field-label">Medical history factor</span>
          <span class="field-value">{{ bundle.medical_history_factor }}×</span>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-header-title">Medical history</span></div>
      <div class="card-body">
        {% if bundle.profile.medical_history %}
          {% for entry in bundle.profile.medical_history %}
          <div class="consent-row">
            <div><div class="consent-name">{{ entry.condition }}</div>
            <div class="consent-desc">Diagnosed {{ entry.diagnosed_year }} · {{ entry.status }}</div></div>
          </div>
          {% endfor %}
        {% else %}
          <p class="explain">No medical history recorded.</p>
        {% endif %}
      </div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-header-title">Family history</span></div>
      <div class="card-body">
        {% if bundle.profile.family_history %}
          {% for entry in bundle.profile.family_history %}
          <div class="consent-row">
            <div><div class="consent-name">{{ entry.relation | capitalize }} — {{ entry.condition }}</div>
            <div class="consent-desc">Age at onset: {{ entry.age_at_onset }}</div></div>
          </div>
          {% endfor %}
        {% else %}
          <p class="explain">No family history recorded.</p>
        {% endif %}
      </div>
    </div>
    <div class="card">
      <div class="card-header"><span class="card-header-title">Raw full record</span>
        <span class="badge badge-private">Never transmitted</span></div>
      <div class="card-body">
        <p class="explain">This is the exact JSON that lives on your device. The blockchain only ever receives its SHA-256 hash.</p>
        <div class="raw-block">{{ bundle_raw }}</div>
      </div>
    </div>
    {% else %}
    <div class="notice notice-warn">No full record found for this patient ID. Upload a VCF file first.</div>
    {% endif %}
  </div>

  <!-- Timeline -->
  <div class="section" id="timeline">
    <h2>Timeline <span class="badge badge-private">Private</span></h2>
    <p class="subtitle">Your growing record — diagnosis, treatment, remission, and everything after. Hash-chained so any tampering is detectable. Periodic anchors on the blockchain create timestamped proof this record existed.</p>
    {% if timeline_entries %}
    <div class="card">
      <div class="card-body">
        {% for entry in timeline_entries %}
        <div class="timeline-entry">
          <div class="timeline-dot"></div>
          <div class="timeline-type">{{ entry.entry_type }}</div>
          <div class="consent-name" style="margin-bottom:2px">{{ entry.data | tojson }}</div>
          <div class="timeline-hash">hash: {{ entry.entry_hash[:20] }}... | prev: {{ entry.previous_entry_hash[:12] }}...</div>
        </div>
        {% endfor %}
      </div>
    </div>
    {% else %}
    <div class="notice notice-warn">No timeline entries found. Records are added automatically as you upload data.</div>
    {% endif %}
  </div>

  <!-- On-chain -->
  <div class="section" id="onchain">
    <h2>On-chain data <span class="badge badge-permanent">Permanent</span></h2>
    <p class="subtitle">These records are mined onto the blockchain and cannot be changed or deleted. This is intentional — it's what makes the record tamper-evident. The trade-off is that you should never consent to mining anything you'd want erased later. That's why only hashes and aggregate numbers go here.</p>
    {% if onchain_records %}
    {% for rec in onchain_records %}
    <div class="card">
      <div class="card-header">
        <span class="card-header-title">Block {{ rec.block_index }}</span>
        <span class="badge badge-public">Network-visible</span>
      </div>
      <div class="card-body">
        <div class="field-grid">
          <span class="field-label">Person ID hash</span>
          <span class="field-value hash">{{ rec.person_id_hash[:32] }}...</span>
          <span class="field-label">Off-chain pointer</span>
          <span class="field-value hash">{{ rec.off_chain_ref[:32] }}...</span>
          <span class="field-label">Risk score</span>
          <span class="field-value">{{ rec.adjusted_risk_score }}</span>
          <span class="field-label">Mutation burden</span>
          <span class="field-value">{{ rec.tumor_mutation_burden }}</span>
          <span class="field-label">Block hash</span>
          <span class="field-value hash">{{ rec.block_hash[:32] }}...</span>
        </div>
      </div>
    </div>
    {% endfor %}
    {% else %}
    <div class="notice notice-warn">No on-chain records found. Your data has not yet been mined.</div>
    {% endif %}
  </div>

  <!-- Research pool -->
  <div class="section" id="research">
    <h2>Research pool <span class="badge badge-public">Public</span></h2>
    <p class="subtitle">What anonymous researchers can see when they query the public research pool. Your name, family history, and medical details are absent. You can revoke this at any time — it will be permanently deleted from the pool.</p>
    {% if research_contribution %}
    <div class="notice">Your data is currently in the public research pool.</div>
    <div class="card">
      <div class="card-body">
        <p class="explain">This is exactly what appears when someone queries <code>/research/search</code> with no authentication:</p>
        <div class="raw-block">{{ research_contribution }}</div>
        <form method="POST" action="/revoke" style="margin-top:14px">
          <input type="hidden" name="person_id" value="{{ patient_id }}">
          <button type="submit" class="btn btn-danger">Revoke &amp; delete from research pool</button>
        </form>
      </div>
    </div>
    {% else %}
    <div class="notice notice-warn">Your data is not currently in the public research pool.</div>
    <form method="POST" action="/donate">
      <input type="hidden" name="person_id" value="{{ patient_id }}">
      <input type="hidden" name="categories" value="genomic_summary">
      <input type="hidden" name="categories" value="risk_score">
      <button type="submit" class="btn btn-primary">Donate de-identified data to research</button>
    </form>
    {% endif %}
  </div>

  <!-- Consent controls -->
  <div class="section" id="consent">
    <h2>Consent &amp; access</h2>
    <p class="subtitle">What you've consented to share. You can revoke any category — it will be removed from the public research pool immediately. It cannot be removed from the blockchain, because the blockchain only holds a hash, not the data itself.</p>
    <div class="card">
      <div class="card-body">
        {% for cat in consent_categories %}
        <div class="consent-row">
          <div>
            <div class="consent-name">{{ cat.name }}</div>
            <div class="consent-desc">{{ cat.description }}</div>
          </div>
          <span class="pill {% if cat.granted %}pill-on{% else %}pill-off{% endif %}">
            {% if cat.granted %}Shared{% else %}Not shared{% endif %}
          </span>
        </div>
        {% endfor %}
      </div>
    </div>
  </div>

  <!-- Plain-language explainer -->
  <div class="section" id="understand">
    <h2>What this means for you</h2>
    <div class="card">
      <div class="card-body">
        <p class="explain"><strong>The blockchain is not a health record system.</strong> It's a tamper-evidence mechanism. What it guarantees is that a record existed at a certain moment and hasn't been changed since — nothing more. It cannot produce, recommend, or influence any treatment.</p>
        <p class="explain"><strong>Your full data never leaves this device</strong> unless you explicitly donate it to the research pool. The network only sees numbers: a risk score and a mutation count. Your gene names, your family history, and your medical conditions are not on the network.</p>
        <p class="explain"><strong>Research pool contributions are deletable.</strong> Unlike the blockchain record (which is permanent by design), anything you donate to the research pool can be removed immediately and completely. The blockchain's hash pointer will remain — it just becomes an unresolvable pointer.</p>
        <p class="explain"><strong>Risk scores are illustrative.</strong> The numbers on this page are computed by software that has not been clinically validated. They are not a diagnosis and should not inform any medical decision without the input of a qualified clinician.</p>
      </div>
    </div>
  </div>

</main>
</div>
</body>
</html>"""


def add_patient_route(app, off_chain_store, research_pool, consent_store,
                       node_url="http://localhost:5001"):
    """Adds GET /patient?id=<person_id> to an existing Flask app."""
    from flask import request, render_template_string
    import json, hashlib, requests as req

    @app.route("/patient", methods=["GET"])
    def patient_dashboard():
        patient_id = request.args.get("id", "").strip()
        if not patient_id:
            return "Missing ?id= parameter", 400

        # Gather all data for this patient
        import json as _json
        try:
            with open("offchain_store.json") as f:
                all_bundles = _json.load(f)
        except Exception:
            all_bundles = {}
        patient_bundle = None
        bundle_raw = "{}"
        for bundle_hash, bundle in all_bundles.items():
            profile = bundle.get("profile", {})
            if profile.get("person_id") == patient_id:
                patient_bundle = bundle
                bundle_raw = json.dumps(bundle, indent=2, default=str)
                break

        # On-chain records matching this patient's hashed ID
        pid_hash = hashlib.sha256(patient_id.encode()).hexdigest()
        onchain_records = []
        try:
            chain_data = req.get(f"{node_url}/chain", timeout=5).json()
            for block in chain_data.get("chain", []):
                rec = block.get("prediction_record", {})
                if rec.get("person_id_hash") == pid_hash:
                    onchain_records.append({
                        "block_index": block["index"],
                        "block_hash": block["hash"],
                        **rec
                    })
        except Exception:
            pass

        # Research pool contribution
        all_contributions = research_pool.all_contributions()
        hashed_id = hashlib.sha256(patient_id.encode()).hexdigest()[:24]
        research_contribution = all_contributions.get(hashed_id)
        research_contribution_str = json.dumps(research_contribution, indent=2) if research_contribution else None

        # Consent status
        from research_consent import CONSENT_CATEGORIES, SENSITIVE_CONSENT_CATEGORIES
        consent_data = consent_store._read()
        consent_record_data = consent_data.get(patient_id, {})
        granted_cats = set(consent_record_data.get("categories", []))
        consent_display = []
        cat_descriptions = {
            "genomic_summary": "Gene names and mutation count from your genomic data",
            "risk_score": "Your computed risk score (a single number)",
            "demographics_bucketed": "Age range (not exact age) and sex",
            "epigenetic_summary": "Which genes showed methylation changes",
            "sexual_health_history": "Sexual health and reproductive history (separate opt-in required)",
        }
        for cat in CONSENT_CATEGORIES + SENSITIVE_CONSENT_CATEGORIES:
            consent_display.append({
                "name": cat,
                "description": cat_descriptions.get(cat, ""),
                "granted": cat in granted_cats,
            })

        bundle_size = len(bundle_raw)
        onchain_size = sum(len(json.dumps(r)) for r in onchain_records)
        onchain_pct = round(onchain_size / bundle_size * 100, 1) if bundle_size else 0

        return render_template_string(
            PATIENT_DASHBOARD_TEMPLATE,
            patient_id=patient_id,
            bundle=patient_bundle,
            bundle_raw=bundle_raw,
            bundle_size=bundle_size,
            offchain_count=len(all_bundles),
            timeline_count=0,  # wired in when PersonalTimeline is integrated
            timeline_entries=[],
            integrity_status="Verified" if patient_bundle else "No data",
            onchain_records=onchain_records,
            onchain_count=len(onchain_records),
            onchain_size=onchain_size,
            onchain_pct=onchain_pct,
            research_contribution=research_contribution_str,
            consent_categories=consent_display,
        )
