"""
AI grounding and hallucination protection.

THE REAL PROBLEM: a language model will produce plausible-sounding text
regardless of whether it matches the actual data. In a medical research
context, a confident but wrong statement ("BRCA1 appears in 47% of
records") is not just annoying -- it could mislead a researcher or,
worse, a patient making decisions.

THIS MODULE:
  1. Extracts verifiable factual claims from an AI response
  2. Checks each claim against the actual chain/research pool data
  3. Returns a grounded response with a status per claim:
       "chain_verified"  -- claim matches chain data exactly
       "chain_partial"   -- claim is directionally correct but imprecise
       "unverified"      -- claim could not be checked against chain data
       "contradicted"    -- claim directly conflicts with chain data
  4. Never suppresses a contradicted claim silently -- it shows it
     alongside the correction, so the user sees both

ON TRAINING DATA -- stated explicitly:
  The AI model does not learn from or update on chain data. Its weights
  are fixed. What happens: chain data is assembled as context, passed
  to the model at query time, and the model produces a response from
  that context. The model has no memory of previous queries. Each call
  is independent. The chain grows. The model reads it fresh each time.
  They run in parallel -- the chain's growth does not change the model.

ON EQUAL ACCESS:
  Every caller to the public AI endpoints receives the same context --
  the same chain data, the same research pool, the same model. No one
  receives more or less than the data the chain contains at that moment.
  The only differentiation is the private patient view (which reads that
  patient's own off-chain bundle -- never anyone else's).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Optional
from chain_analytics import ChainAnalytics


@dataclass
class GroundedClaim:
    claim_text: str
    status: str          # "chain_verified" | "chain_partial" | "unverified" | "contradicted"
    chain_value: Optional[Any]    # what the chain actually shows
    ai_value: Optional[str]       # what the AI said


@dataclass
class GroundedResponse:
    original_response: str
    grounded_claims: List[GroundedClaim]
    overall_status: str   # "fully_grounded" | "partially_grounded" | "contains_contradictions"
    verification_note: str
    model_note: str = (
        "The AI model does not learn from or update on chain data. "
        "Its weights are fixed at training time. Chain data is passed "
        "as context at query time only. The chain grows independently."
    )
    equal_access_note: str = (
        "Every public caller receives identical context: the same chain, "
        "the same research pool, the same model. No one gets more or less."
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_response": self.original_response,
            "grounded_claims": [asdict(c) for c in self.grounded_claims],
            "overall_status": self.overall_status,
            "verification_note": self.verification_note,
            "model_note": self.model_note,
            "equal_access_note": self.equal_access_note,
        }


def _extract_numeric(text: str, keyword: str) -> Optional[float]:
    """Find a number near a keyword in text."""
    pattern = rf"(\d+\.?\d*)\s*{re.escape(keyword)}|{re.escape(keyword)}\s*(\d+\.?\d*)"
    matches = re.findall(pattern, text, re.IGNORECASE)
    for m in matches:
        val = m[0] or m[1]
        if val:
            try:
                return float(val)
            except ValueError:
                pass
    return None


def ground_response(ai_response: str, node_url: str = "http://localhost:5001",
                     offchain_path: str = "offchain_store.json") -> GroundedResponse:
    """
    Main entry point: takes an AI response string, extracts checkable
    claims, verifies each against the actual chain data, returns a
    GroundedResponse with a status per claim.

    This does NOT rewrite the AI's response -- it annotates it.
    A contradicted claim is shown as-is alongside the correction,
    so the user sees both what the AI said and what is actually true.
    """
    analytics = ChainAnalytics(node_url=node_url, offchain_store_path=offchain_path)

    try:
        chain_summary = analytics.chain_summary()
        risk_dist = analytics.risk_distribution()
    except Exception:
        chain_summary = {}
        risk_dist = {}

    actual_record_count = chain_summary.get("research_records", 0)
    actual_risk_min = chain_summary.get("risk_scores", {}).get("min")
    actual_risk_max = chain_summary.get("risk_scores", {}).get("max")
    actual_risk_mean = chain_summary.get("risk_scores", {}).get("mean")
    actual_genes = dict(chain_summary.get("most_frequent_genes", []))

    claims: List[GroundedClaim] = []

    # Check 1: Record count claim
    stated_records = _extract_numeric(ai_response, "research records")
    if stated_records is not None:
        if int(stated_records) == actual_record_count:
            status = "chain_verified"
        elif abs(int(stated_records) - actual_record_count) <= 1:
            status = "chain_partial"
        else:
            status = "contradicted"
        claims.append(GroundedClaim(
            claim_text=f"AI states {int(stated_records)} research records",
            status=status,
            chain_value=actual_record_count,
            ai_value=str(int(stated_records)),
        ))

    # Check 2: Risk range claims
    stated_min = _extract_numeric(ai_response, "min") or _extract_numeric(ai_response, "minimum")
    if stated_min and actual_risk_min:
        diff = abs(stated_min - actual_risk_min)
        claims.append(GroundedClaim(
            claim_text=f"AI states min risk {stated_min}",
            status="chain_verified" if diff < 0.01 else ("chain_partial" if diff < 0.1 else "contradicted"),
            chain_value=actual_risk_min,
            ai_value=str(stated_min),
        ))

    stated_max = _extract_numeric(ai_response, "max") or _extract_numeric(ai_response, "maximum")
    if stated_max and actual_risk_max:
        diff = abs(stated_max - actual_risk_max)
        claims.append(GroundedClaim(
            claim_text=f"AI states max risk {stated_max}",
            status="chain_verified" if diff < 0.01 else ("chain_partial" if diff < 0.1 else "contradicted"),
            chain_value=actual_risk_max,
            ai_value=str(stated_max),
        ))

    # Check 3: Gene frequency claims
    for gene in ["BRCA1", "BRCA2", "TP53", "MLH1", "KRAS", "EGFR", "CDKN2A", "PALB2"]:
        if gene in ai_response.upper():
            stated_count = _extract_numeric(ai_response, gene)
            actual_count = actual_genes.get(gene, 0)
            if stated_count is not None:
                status = "chain_verified" if int(stated_count) == actual_count else "contradicted"
            else:
                # Gene mentioned but no specific count claimed -- unverified but not wrong
                status = "chain_verified" if actual_count > 0 else "unverified"
            claims.append(GroundedClaim(
                claim_text=f"AI mentions gene {gene}",
                status=status,
                chain_value=actual_count,
                ai_value=str(int(stated_count)) if stated_count else "mentioned (no count stated)",
            ))

    # Check 4: Risk distribution claims
    if "0.6-0.8" in ai_response:
        highest_bucket = max(risk_dist.items(), key=lambda x: x[1]) if risk_dist else ("unknown", 0)
        status = "chain_verified" if highest_bucket[0] == "0.6-0.8" else "contradicted"
        claims.append(GroundedClaim(
            claim_text="AI claims most records in 0.6-0.8 risk range",
            status=status,
            chain_value=f"highest bucket is actually {highest_bucket[0]} ({highest_bucket[1]} records)",
            ai_value="0.6-0.8",
        ))

    # If no verifiable claims found, everything is unverified
    if not claims:
        claims.append(GroundedClaim(
            claim_text="No verifiable numeric/factual claims found in response",
            status="unverified",
            chain_value=None,
            ai_value=None,
        ))

    statuses = {c.status for c in claims}
    if "contradicted" in statuses:
        overall = "contains_contradictions"
        verification_note = (
            "WARNING: one or more AI claims contradict the actual chain data. "
            "The contradiction is shown above with the correct chain value. "
            "Always trust the chain value over the AI's stated value."
        )
    elif "unverified" in statuses and "chain_verified" not in statuses:
        overall = "unverified"
        verification_note = "No claims could be verified against chain data -- treat as AI inference only."
    elif "chain_partial" in statuses:
        overall = "partially_grounded"
        verification_note = "Most claims verified against chain data with minor discrepancies noted."
    else:
        overall = "fully_grounded"
        verification_note = "All checkable claims verified against actual chain data."

    return GroundedResponse(
        original_response=ai_response,
        grounded_claims=claims,
        overall_status=overall,
        verification_note=verification_note,
    )


if __name__ == "__main__":
    import json
    from ai_integration import explain_risk_record
    from chain_analytics import ChainAnalytics

    print("=== Grounding test: correct AI response ===\n")
    analytics = ChainAnalytics("http://localhost:5001", "offchain_store.json")
    summary = analytics.chain_summary()

    correct_response = explain_risk_record(
        summary,
        _stub_response=(
            f"The chain holds {summary.get('research_records', 0)} research records. "
            f"Risk scores range from {summary.get('risk_scores', {}).get('min')} "
            f"to {summary.get('risk_scores', {}).get('max')}. "
            f"Most records are in the 0.6-0.8 risk range."
        )
    )
    grounded = ground_response(correct_response)
    print(f"Status: {grounded.overall_status}")
    for c in grounded.grounded_claims:
        print(f"  [{c.status:20s}] {c.claim_text}")
        if c.status == "contradicted":
            print(f"    AI said: {c.ai_value} | Chain says: {c.chain_value}")

    print()
    print("=== Grounding test: hallucinated AI response ===\n")
    hallucinated = explain_risk_record(
        summary,
        _stub_response=(
            "The chain holds 500 research records. "
            "Risk scores range from 0.1 to 0.99. "
            "BRCA1 appears in 47 records. "
            "Most records are in the 0.6-0.8 risk range."
        )
    )
    grounded2 = ground_response(hallucinated)
    print(f"Status: {grounded2.overall_status}")
    for c in grounded2.grounded_claims:
        marker = "⚠" if c.status == "contradicted" else "✓"
        print(f"  {marker} [{c.status:20s}] {c.claim_text}")
        if c.status == "contradicted":
            print(f"    AI said: {c.ai_value} | Chain actually has: {c.chain_value}")
    print()
    print(grounded2.verification_note)
    print()
    print("Model note:", grounded2.model_note)
    print()
    print("Equal access note:", grounded2.equal_access_note)
