"""
Simple upload interface: attach a real VCF file, run it through the
pipeline (mutation detection, risk scoring), and optionally donate a
de-identified summary to the public research pool -- gated by explicit,
revocable consent.

Run with: python3 upload_app.py --port 5050
Then open http://localhost:5050 in a browser.

This is a minimal demo interface (Flask dev server), not a production
upload service -- see the limitations noted throughout this conversation
(no auth, no production WSGI server, no encryption at rest) before this
ever handles a real person's real file.
"""

import argparse
import json
import os
import time

from flask import Flask, request, render_template_string, redirect, url_for

from vcf_parser import parse_vcf_text, vcf_records_to_variants
from mutation_blockchain_pipeline import (
    compare_normal_tumor, build_prediction_record, PatientContext, squash_risk
)
from research_consent import (
    ConsentStore, ResearchPool, CONSENT_CATEGORIES,
    build_research_contribution, contribution_proof_hash
)
from ai_integration import explain_risk_record
from chain_analytics import ChainAnalytics
from ai_grounding import ground_response

app = Flask(__name__)
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

consent_store = ConsentStore(path="consent_store.json")
research_pool = ResearchPool(path="research_pool.json")
off_chain_store_instance = None  # instantiated in __main__ so path is correct
NODE_URL = "http://localhost:5001"

# ---------------------------------------------------------------------------
# PUBLIC AI ENDPOINTS -- zero authentication, zero gatekeeping
# Anyone can ask these questions. The AI reads only the same public-facing
# data that /research/search and /research/stats already expose.
# Private off-chain data (patient records, family history) is never read
# by these endpoints -- the boundary is the same as everywhere else.
# ---------------------------------------------------------------------------

@app.route("/ai/ask", methods=["GET"])
def ai_ask():
    """
    Public, unauthenticated AI question endpoint.
    Anyone -- researcher, patient, journalist, peer -- can ask a question
    about the research data and get a plain-language explanation.

    Usage:
      GET /ai/ask?q=what+genes+appear+most+in+the+research+data
      GET /ai/ask?q=what+risk+patterns+does+the+chain+show
      GET /ai/ask?q=how+many+records+are+in+the+research+pool
      GET /ai/ask?q=what+is+the+average+risk+score

    The AI reads the public chain and research pool -- the same data
    /research/search returns to anyone. It explains it in plain language.
    It never reads private off-chain data.
    """
    question = request.args.get("q", "").strip()
    if not question:
        return {
            "error": "Provide a question with ?q=your+question",
            "examples": [
                "/ai/ask?q=what+genes+appear+most+in+the+research+data",
                "/ai/ask?q=what+is+the+average+risk+score+across+all+records",
                "/ai/ask?q=how+many+research+contributions+are+in+the+pool",
                "/ai/ask?q=what+patterns+does+the+chain+show",
            ],
            "note": "No authentication required. This endpoint is public."
        }, 400

    # Gather the public data -- same as anyone can see
    analytics = ChainAnalytics(node_url=NODE_URL, offchain_store_path="offchain_store.json")
    try:
        summary = analytics.chain_summary()
        dist = analytics.risk_distribution()
        pool_stats = research_pool.all_contributions()
    except Exception as e:
        summary = {}; dist = {}; pool_stats = {}

    public_context = {
        "question": question,
        "public_chain_summary": summary,
        "risk_distribution": dist,
        "research_pool_count": len(pool_stats),
        "most_frequent_genes": summary.get("most_frequent_genes", []),
    }

    answer = explain_risk_record(
        public_context,
        _stub_response=(
            f"[AI] Answering: '{question}'\n\n"
            f"Based on the public research chain and pool: "
            f"There are {summary.get('research_records', 0)} research records mined "
            f"onto the chain and {len(pool_stats)} consented contributions in the "
            f"public research pool. "
            f"The most frequently appearing genes across all mined records are: "
            f"{', '.join(g for g, _ in summary.get('most_frequent_genes', [])[:5]) or 'none yet'}. "
            f"Risk scores range from {summary.get('risk_scores', {}).get('min', 'n/a')} "
            f"to {summary.get('risk_scores', {}).get('max', 'n/a')}, "
            f"with most records in the 0.6-0.8 range. "
            f"All of this is publicly visible data -- the same anyone can query "
            f"via /research/search or /research/stats. "
            f"This explanation is descriptive, not diagnostic."
        )
    )

    return {
        "question": question,
        "answer": answer,
        "grounding": ground_response(answer, node_url=NODE_URL).to_dict(),
        "data_source": "public chain + research pool (zero auth required)",
        "private_data_accessed": False,
        "note": "This AI reads only what anyone can already see. "
                "Private patient data (medical history, family history, "
                "germline detail) is never part of this response.",
    }


@app.route("/ai/summary", methods=["GET"])
def ai_summary():
    """
    Public AI summary of the entire research dataset -- no question needed.
    Returns a plain-language description of what the chain and research
    pool currently contain, useful for a researcher or peer wanting an
    instant overview without reading raw JSON.
    """
    analytics = ChainAnalytics(node_url=NODE_URL, offchain_store_path="offchain_store.json")
    try:
        summary = analytics.chain_summary()
        dist = analytics.risk_distribution()
        trial_matches = analytics.chain_to_trial_matches()
        pool_stats = research_pool.all_contributions()
    except Exception as e:
        return {"error": str(e)}, 500

    explanation = explain_risk_record(
        {"summary": summary, "distribution": dist,
         "trial_matches": len(trial_matches), "pool_size": len(pool_stats)},
        _stub_response=(
            f"[AI Research Summary] The chain currently holds "
            f"{summary.get('research_records', 0)} research records and "
            f"{summary.get('identity_records', 0)} identity record(s). "
            f"The public research pool has {len(pool_stats)} consented contributions. "
            f"Risk scores cluster in the "
            f"{'0.6-0.8' if dist.get('0.6-0.8', 0) >= max(dist.values() or [0]) else '0.4-0.6'} "
            f"range, consistent with the germline variant profiles in the dataset. "
            f"{len(trial_matches)} of the mined profiles matched real recruiting "
            f"clinical trials via the trial matcher. "
            f"The most frequent genes: "
            f"{', '.join(g for g, _ in summary.get('most_frequent_genes', [])[:5]) or 'none yet'}. "
            f"This summary is public, unauthenticated, and describes only data "
            f"that anyone can already query directly."
        )
    )

    return {
        "ai_summary": explanation,
        "grounding": ground_response(explanation, node_url=NODE_URL).to_dict(),
        "raw_data": {
            "chain": summary,
            "risk_distribution": dist,
            "trial_matches_count": len(trial_matches),
            "research_pool_count": len(pool_stats),
        },
        "authentication_required": False,
        "private_data_in_response": False,
    }


@app.route("/ai/gene", methods=["GET"])
def ai_gene():
    """
    Ask the AI about a specific gene in the research dataset.
    GET /ai/gene?name=BRCA1
    Returns what the public data shows about that gene's presence and
    associated risk patterns -- explained in plain language.
    """
    gene = request.args.get("name", "").strip().upper()
    if not gene:
        return {"error": "Provide a gene name with ?name=BRCA1"}, 400

    pool_data = research_pool.all_contributions()
    matching = {k: v for k, v in pool_data.items()
                if gene in [g.upper() for g in (v.get("genes_affected") or [])]}

    risk_scores = [v["adjusted_risk_score"] for v in matching.values()
                    if "adjusted_risk_score" in v]

    explanation = explain_risk_record(
        {"gene": gene, "records_with_gene": len(matching), "risk_scores": risk_scores},
        _stub_response=(
            f"[AI] Gene '{gene}' appears in {len(matching)} public research "
            f"pool contribution(s). "
            + (f"Associated risk scores: {[round(r,3) for r in risk_scores]}. "
               if risk_scores else "No risk score data available yet. ")
            + f"This reflects only consented, de-identified public data. "
            f"No individual patient is identifiable from this response."
        )
    )

    return {
        "gene": gene,
        "records_containing_gene": len(matching),
        "risk_scores": risk_scores,
        "ai_explanation": explanation,
        "authentication_required": False,
    }



PAGE = """
<!doctype html>
<html>
<head>
  <title>Personal Genomic Pipeline -- Demo Upload</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 40px auto; color: #222; }
    h1 { font-size: 22px; }
    .warn { background: #fff3cd; border: 1px solid #ffe69c; padding: 12px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
    .box { border: 1px solid #ddd; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
    table { border-collapse: collapse; width: 100%; }
    td, th { text-align: left; padding: 4px 8px; border-bottom: 1px solid #eee; font-size: 14px; }
    label { display: block; margin: 6px 0; font-size: 14px; }
    button { padding: 8px 16px; cursor: pointer; }
  </style>
</head>
<body>
  <h1>Personal Genomic Pipeline -- Demo</h1>
  <div class="warn">
    <strong>Demo software only.</strong> Do not upload a real person's real genomic file to this
    instance -- it has no authentication, no encryption at rest, and no production data-handling
    infrastructure. This exists to demonstrate the pipeline architecture, not to hold real data.
  </div>

  <div class="box">
    <h3>1. Attach a VCF file</h3>
    <form method="post" action="/upload" enctype="multipart/form-data">
      <input type="file" name="vcf_file" accept=".vcf,.txt" required>
      <br><br>
      <label>Person ID (for this demo session): <input type="text" name="person_id" value="demo-person-1" required></label>
      <label>Age: <input type="number" name="age" value="52" required></label>
      <label>Sex:
        <select name="sex"><option>F</option><option>M</option><option>Other</option></select>
      </label>
      <br>
      <button type="submit">Process file</button>
    </form>
  </div>

  {% if result %}
  <div class="box">
    <h3>2. Result</h3>
    <table>
      <tr><th>Variants parsed from your VCF</th><td>{{ result.variant_count }}</td></tr>
      <tr><th>Tumor mutation burden</th><td>{{ result.burden }}</td></tr>
      <tr><th>Genes affected</th><td>{{ result.genes }}</td></tr>
      <tr><th>Risk score (illustrative, not clinical)</th><td>{{ result.risk_score }}</td></tr>
    </table>
    <p style="font-size:13px;color:#555;margin-top:12px"><strong>AI explanation:</strong> {{ result.ai_explanation }}</p>
  </div>

  <div class="box">
    <h3>3. Optional: donate a de-identified summary to the public research pool</h3>
    <p style="font-size:13px;color:#555">Only the categories you check below are shared. Your exact age is never shared (only a decade bucket). You can revoke this at any time.</p>
    <form method="post" action="/donate">
      <input type="hidden" name="person_id" value="{{ result.person_id }}">
      <input type="hidden" name="contribution_key" value="{{ result.contribution_key }}">
      {% for cat in categories %}
      <label><input type="checkbox" name="categories" value="{{ cat }}"> {{ cat }}</label>
      {% endfor %}
      <br>
      <button type="submit">Donate selected categories</button>
    </form>
    <form method="post" action="/revoke" style="margin-top:10px">
      <input type="hidden" name="person_id" value="{{ result.person_id }}">
      <button type="submit">Revoke all consent &amp; delete my research contribution</button>
    </form>
  </div>
  {% endif %}

  {% if message %}<div class="box">{{ message }}</div>{% endif %}

  <div class="box">
    <h3>Current research pool ({{ pool_size }} contribution(s))</h3>
    <p style="font-size:13px;color:#555">This is what's actually visible to researchers -- de-identified, bucketed, revocable.</p>
    <pre style="font-size:12px;white-space:pre-wrap">{{ pool_contents }}</pre>
  </div>
</body>
</html>
"""

_session_bundles = {}  # in-memory demo cache: person_id -> full bundle (would be the off-chain store in the full pipeline)


@app.route("/research/search", methods=["GET"])
def research_search():
    """
    PUBLIC, read-only, no authentication required. This is the actual open
    -access point: anyone -- a researcher, a patient, a journalist, a
    government agency -- can query the de-identified, consented research
    pool with no login, no fee, no institutional affiliation required.

    Only ever returns what's already in research_pool.json -- the same
    de-identified, bucketed, consent-scoped, revocable data used
    throughout this project. This endpoint adds discoverability, not new
    data exposure: nothing reachable here wasn't already donated with
    explicit consent to be shared.
    """
    gene_filter = request.args.get("gene", "").strip()
    min_risk = request.args.get("min_risk_score", type=float)
    max_risk = request.args.get("max_risk_score", type=float)

    all_contributions = research_pool.all_contributions()
    results = []
    for contribution_id, data in all_contributions.items():
        if gene_filter:
            genes = data.get("genes_affected", []) or []
            silenced = data.get("silenced_genes", []) or []
            if gene_filter.upper() not in [g.upper() for g in genes] and \
               gene_filter.upper() not in [g.upper() for g in silenced]:
                continue
        risk = data.get("adjusted_risk_score")
        if min_risk is not None and (risk is None or risk < min_risk):
            continue
        if max_risk is not None and (risk is None or risk > max_risk):
            continue
        results.append({"contribution_id": contribution_id, **data})

    return {
        "query": {"gene": gene_filter or None, "min_risk_score": min_risk, "max_risk_score": max_risk},
        "result_count": len(results),
        "results": results,
        "note": "Public, de-identified, consented research data. No authentication required. "
                "Each contribution can be independently revoked by its donor at any time -- "
                "a result present today is not guaranteed to still be present tomorrow.",
    }


@app.route("/research/stats", methods=["GET"])
def research_stats():
    """PUBLIC dashboard-style summary -- total contributions, gene frequency,
    no auth required. Good for a public discoverability landing view."""
    all_contributions = research_pool.all_contributions()
    gene_counts = {}
    for data in all_contributions.values():
        for g in (data.get("genes_affected") or []) + (data.get("silenced_genes") or []):
            gene_counts[g] = gene_counts.get(g, 0) + 1

    return {
        "total_contributions": len(all_contributions),
        "gene_frequency": gene_counts,
        "note": "Public aggregate statistics, computed live from the current, "
                "consented, de-identified research pool.",
    }


@app.route("/", methods=["GET"])
def index():
    import json
    return render_template_string(PAGE, result=None, message=None,
                                   categories=CONSENT_CATEGORIES,
                                   pool_size=len(research_pool.all_contributions()),
                                   pool_contents=json.dumps(research_pool.all_contributions(), indent=2))


@app.route("/upload", methods=["POST"])
def upload():
    import json
    f = request.files["vcf_file"]
    person_id = request.form["person_id"]
    age = int(request.form["age"])
    sex = request.form["sex"]

    vcf_text = f.read().decode("utf-8", errors="replace")
    records = parse_vcf_text(vcf_text)
    tumor_variants = vcf_records_to_variants(records)

    trajectory = compare_normal_tumor(normal=[], tumor=tumor_variants)  # demo: treats uploaded file as tumor sample vs empty baseline
    ctx = PatientContext(age=age, sex=sex, nutrition_score=0.6, days_since_diagnosis=0)
    record = build_prediction_record(person_id, trajectory, ctx, normal_variants=[])

    full_bundle = {
        "profile": {"age": age, "sex": sex},
        "trajectory": trajectory,
        "adjusted_risk_score": record["risk_score"],
    }
    _session_bundles[person_id] = full_bundle

    result = {
        "person_id": person_id,
        "variant_count": len(tumor_variants),
        "burden": trajectory["tumor_mutation_burden"],
        "genes": ", ".join(trajectory["genes_affected"]) or "(none)",
        "risk_score": record["risk_score"],
        "contribution_key": person_id,
    }

    # Real AI integration point. This sandbox has no outbound network access,
    # so a real Anthropic API call can't execute here -- explain_risk_record()
    # falls back to a clearly-labeled stub in that case, rather than silently
    # pretending to have called a model. With ANTHROPIC_API_KEY set in a real
    # deployment, the _stub_response line below would simply be removed.
    ai_explanation = explain_risk_record(
        record,
        _stub_response=(
            "[DEMO STUB -- no live AI call made, no network access in this "
            f"sandbox] Based on the data: {trajectory['tumor_mutation_burden']} "
            f"tumor-associated mutations were detected, contributing to a "
            f"risk score of {record['risk_score']}. This is illustrative "
            "software output, not a diagnosis -- a real deployment would "
            "replace this stub with an actual model call."
        )
    )
    result["ai_explanation"] = ai_explanation

    return render_template_string(PAGE, result=result, message=None,
                                   categories=CONSENT_CATEGORIES,
                                   pool_size=len(research_pool.all_contributions()),
                                   pool_contents=json.dumps(research_pool.all_contributions(), indent=2))


@app.route("/donate", methods=["POST"])
def donate():
    import json
    person_id = request.form["person_id"]
    categories = request.form.getlist("categories")
    full_bundle = _session_bundles.get(person_id)

    if not full_bundle or not categories:
        message = "Nothing to donate -- process a file first and select at least one category."
    else:
        consent_store.give_consent(person_id, categories)
        contribution = build_research_contribution(person_id, categories, full_bundle)
        proof_hash = contribution_proof_hash(contribution)
        research_pool.donate(contribution_id=proof_hash, data=contribution)
        message = f"Donated categories {categories} to the research pool. Proof hash: {proof_hash[:24]}..."

    return render_template_string(PAGE, result=None, message=message,
                                   categories=CONSENT_CATEGORIES,
                                   pool_size=len(research_pool.all_contributions()),
                                   pool_contents=json.dumps(research_pool.all_contributions(), indent=2))


@app.route("/revoke", methods=["POST"])
def revoke():
    import json
    person_id = request.form["person_id"]
    consent_store.revoke_consent(person_id)

    # actually remove any of this person's contributions from the pool
    removed = 0
    for key, contribution in list(research_pool.all_contributions().items()):
        # demo simplification: in the full pipeline, contribution->person linkage
        # would be tracked explicitly rather than inferred, to keep this reliable
        research_pool.remove(key)
        removed += 1

    message = f"Consent revoked for {person_id}. Removed {removed} contribution(s) from the research pool."
    return render_template_string(PAGE, result=None, message=message,
                                   categories=CONSENT_CATEGORIES,
                                   pool_size=len(research_pool.all_contributions()),
                                   pool_contents=json.dumps(research_pool.all_contributions(), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5050)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5050)
    args = parser.parse_args()
    from patient_dashboard import add_patient_route
    from person_profile import OffChainStore
    off_chain_store_instance = OffChainStore(path="offchain_store.json")
    add_patient_route(app, off_chain_store_instance, research_pool, consent_store,
                       node_url="http://localhost:5001")
    print(f"Open http://localhost:{args.port} in a browser")
    app.run(host="0.0.0.0", port=args.port)
