// Genuine cross-language interoperability test: this is real Node.js code
// (not Python), talking to the ACTUAL running Python node_server.py over
// plain HTTP, and independently recomputing SHA-256 hashes using Node's
// own crypto module -- no shared library, no AI translation, just both
// languages correctly implementing the same public standard (SHA-256 +
// a specific canonical JSON serialization).
//
// This is the real point being demonstrated: the network PROTOCOL is
// language-agnostic by design. Any language that can speak HTTP + JSON +
// SHA-256 can participate -- Python is not privileged or required.

const http = require('http');
const crypto = require('crypto');

function fetchJSON(path) {
  return new Promise((resolve, reject) => {
    http.get({ host: 'localhost', port: 5001, path }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => resolve(JSON.parse(body)));
    }).on('error', reject);
  });
}

// Replicates Python's json.dumps(data, sort_keys=True) EXACTLY -- this is
// the genuinely hard part of cross-language hash compatibility: Python's
// default separators are ", " and ": ", and sort_keys sorts nested dict
// keys too. JSON.stringify does neither of these by default, so this has
// to be built by hand to byte-match Python's canonical serialization.
function pythonCanonicalJSON(obj) {
  if (obj === null) return 'null';
  if (typeof obj === 'number') return String(obj);
  if (typeof obj === 'string') return JSON.stringify(obj); // string escaping matches
  if (Array.isArray(obj)) {
    return '[' + obj.map(pythonCanonicalJSON).join(', ') + ']';
  }
  if (typeof obj === 'object') {
    const keys = Object.keys(obj).sort(); // sort_keys=True, recursively
    const parts = keys.map(k => JSON.stringify(k) + ': ' + pythonCanonicalJSON(obj[k]));
    return '{' + parts.join(', ') + '}';
  }
  return String(obj);
}

function computeBlockHash(block) {
  const blockBody = {
    index: block.index,
    timestamp_ms: Math.round(block.timestamp * 1000),
    prediction_record: block.prediction_record,
    maxwell_sig: block.maxwell_sig,
    previous_hash: block.previous_hash,
    nonce: block.nonce,
  };
  const canonical = pythonCanonicalJSON(blockBody);
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

(async () => {
  console.log('=== JavaScript client fetching from the REAL Python node server (port 5001) ===\n');
  const data = await fetchJSON('/chain');
  console.log(`Fetched ${data.length} blocks from Python server via plain HTTP.\n`);

  let allMatch = true;
  for (const block of data.chain) {
    const jsComputedHash = computeBlockHash(block);
    const pythonStoredHash = block.hash;
    const match = jsComputedHash === pythonStoredHash;
    allMatch = allMatch && match;

    console.log(`Block ${block.index}:`);
    console.log(`  Python's stored hash:     ${pythonStoredHash}`);
    console.log(`  JavaScript-computed hash: ${jsComputedHash}`);
    console.log(`  MATCH: ${match}\n`);
  }

  console.log(allMatch
    ? '=== SUCCESS: JavaScript independently reproduces every hash Python computed. Real cross-language interoperability, no AI involved. ==='
    : '=== MISMATCH: canonical serialization does not match between the two languages ===');
})();
